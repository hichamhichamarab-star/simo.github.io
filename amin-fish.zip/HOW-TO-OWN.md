# 👑 Guide de prise en main — Votre site vous appartient

Ce guide explique comment **devenir propriétaire à 100 %** de ce site, le modifier, et l'héberger où vous voulez.

---

## 1. 🎯 Vous avez déjà tout

Vous avez reçu :
- ✅ Le **code source complet** (HTML, CSS, JavaScript) — non protégé, non chiffré
- ✅ Toutes les **images** du restaurant
- ✅ Un **QR code** pointant vers le site
- ✅ Une **URL publique** déployée
- ✅ Un fichier `site-data.json` simple à modifier

**Aucune dépendance propriétaire.** Vous pouvez le copier, l'éditer, le revendre, le donner.

---

## 2. ✏️ Modifier le contenu (sans toucher au code)

Toute la vie du site est dans **`site-data.json`**. C'est un simple fichier texte.

### Exemple : changer un prix
1. Ouvrir `site-data.json` (clic droit → "Ouvrir avec Bloc-notes" ou VS Code)
2. Chercher `"price": 220`
3. Remplacer par `"price": 250`
4. Sauvegarder
5. Re-téléverser le fichier sur l'hébergement → c'est mis à jour

### Exemple : ajouter un plat
Ajouter dans la catégorie voulue :
```json
{
  "name": "Nouvelle dorade grillée",
  "nameAr": "دوريد مشوي",
  "price": 200,
  "desc": "Dorade entière grillée au four, citron, herbes"
}
```

### Exemple : changer les horaires
Modifier la section `hours` :
```json
{ "day": "Lundi", "open": "10:00", "close": "23:00", "closed": false }
```
Mettre `"closed": true` pour un jour de fermeture.

### Exemple : changer le téléphone
Modifier `phone` et `phoneAlt` dans `site-data.json`.

---

## 3. 🎨 Modifier le design (couleurs, polices)

Toutes les couleurs sont centralisées en haut de **`styles.css`** :

```css
:root {
  --c-primary: #0a3d4f;     /* Couleur principale (titres, header) */
  --c-accent: #e85d4d;      /* Couleur d'accent (boutons) */
  --c-gold: #f0a500;        /* Doré (décorations) */
  --c-sand: #f5e6c8;        /* Sable (fonds clairs) */
}
```

Changez ces codes hexadécimaux → tout le site change de couleur.
**Astuce** : https://coolors.co/ pour choisir des couleurs harmonieuses.

---

## 4. 🖼️ Remplacer les images

1. Préparez votre photo (JPG ou PNG, idéalement 1200×800px)
2. Donnez-lui **exactement le même nom** que l'ancienne
3. Remplacez l'ancienne image dans le dossier `images/`

Ou modifiez le `src` dans `index.html` si vous voulez changer le nom.

**Optimisation** : Pour que le site reste rapide, compressez vos images sur https://tinypng.com/ avant de les uploader.

---

## 5. 🌐 Acheter votre propre nom de domaine (recommandé)

L'URL actuelle est une URL de démo. Pour avoir **votredomaine.ma** :

### Étape 1 : Acheter le domaine
- **Maroc** : http://www.registre.ma/ ou https://www.namecheap.com/ (~200 DH/an pour `.ma`)
- Alternatif : `.com` (~100 DH/an) sur Namecheap, OVH, GoDaddy

### Étape 2 : Héberger le site
Quelques hébergeurs fiables (certains gratuits) :
| Hébergeur         | Prix        | Avantages                                      |
|-------------------|-------------|------------------------------------------------|
| **Netlify**       | Gratuit     | Drag & drop, SSL gratuit, très simple          |
| **Vercel**        | Gratuit     | Idem, ultra rapide                             |
| **GitHub Pages**  | Gratuit     | Si vous connaissez Git                         |
| **Hostinger**     | ~30 DH/mois | Domaine + hébergement inclus                   |
| **OVH**           | ~40 DH/mois | Hébergeur français, support en français        |

**Recommandation** : **Netlify** (gratuit, simple) → https://app.netlify.com/drop
1. Allez sur https://app.netlify.com/drop
2. Glissez-déposez le dossier `amin-fish/`
3. Vous obtenez une URL du type `https://snackamine.netlify.app`
4. Reliez votre domaine personnalisé dans les paramètres

### Étape 3 : Relier le domaine à l'hébergement
Dans les paramètres DNS de votre registrar (registre.ma, Namecheap, etc.) :
- Ajoutez les serveurs DNS fournis par Netlify/OVH/Hostinger
- Ou ajoutez un CNAME : `www` → `votresite.netlify.app`

---

## 6. 📢 Référencer le site sur Google

1. Allez sur https://search.google.com/search-console/
2. Cliquez "Ajouter une propriété" → entrez votre URL
3. Vérifiez la propriété (méthode recommandée : balise HTML)
4. Dans le menu "Sitemaps", ajoutez : `https://votresite.ma/sitemap.xml`
5. Dans "Inspection d'URL", entrez votre page d'accueil → "Demander l'indexation"

**Délais** : Google met entre 1 et 4 semaines pour indexer un nouveau site.

### Autres moteurs (Bing, Yahoo)
- **Bing Webmaster** : https://www.bing.com/webmasters (gratuit)
- **Yandex** : https://webmaster.yandex.com (pour la Russie)

---

## 7. 📊 Suivre les visites

Une fois indexé, vous pouvez ajouter :

### Google Analytics (gratuit)
1. Créez un compte sur https://analytics.google.com
2. Obtenez votre ID de mesure (G-XXXXXXXXXX)
3. Ajoutez ce code juste avant `</head>` dans `index.html` :
```html
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

### Plausible / Umami (alternatives respectueuses de la vie privée)
Plus simples et sans cookies.

---

## 8. 📞 Recevoir les réservations

### Option A : Actuelles (sans backend)
Les réservations sont stockées dans le **localStorage** du navigateur de l'utilisateur.
→ C'est un "brouillon". Vous ne les recevez pas encore.

### Option B : Formulaire connecté à votre email (gratuit)
1. Allez sur https://formspree.io/ (gratuit jusqu'à 50 messages/mois)
2. Créez un formulaire, obtenez l'URL : `https://formspree.io/f/xxxxxxx`
3. Dans `script.js`, changez la fonction de soumission du formulaire pour envoyer à Formspree :
```javascript
fetch('https://formspree.io/f/xxxxxxx', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify(data)
});
```

### Option C : Connexion WhatsApp direct
Le bouton WhatsApp est déjà en place. Vous recevez les messages sur votre téléphone.

### Option D : Backend personnalisé
Pour une solution pro, contactez un développeur freelance sur https://www.upwork.com/ ou un dev marocain sur https://www.malt.com/.

---

## 9. 💾 Sauvegardes

**Très important** : faites des sauvegardes régulières !
- Copier tout le dossier `amin-fish/` sur Google Drive / Dropbox
- Versionner avec Git (gratuit, demande un peu de formation)

---

## 10. ❓ Questions fréquentes

**Q : Puis-je vendre ce site à quelqu'un d'autre ?**
R : Oui, c'est votre propriété. Le code n'est sous aucune licence restrictive.

**Q : Le site fonctionne-t-il sans internet ?**
R : Non, c'est un site web en ligne. Mais une fois chargé, les principales sections marchent hors-ligne.

**Q : Peut-on ajouter un système de paiement / commande en ligne ?**
R : Oui, mais cela nécessite plus de développement. Contactez un développeur pour intégrer :
- CMI (Maroc)
- PayPal
- Stripe
- Un système de commande WhatsApp

**Q : Comment avoir une page Facebook / Instagram automatiquement synchronisée ?**
R : Le lien Facebook/Instagram est déjà dans `site-data.json`. Pour automatiser les publications, utilisez Meta Business Suite (gratuit).

**Q : Combien coûte l'hébergement annuel ?**
R : 0 DH (Netlify gratuit) à 500 DH/an (Hostinger premium + domaine.ma).

---

## 📞 Support

Si vous avez besoin d'aide :
- Demandez à un proche qui s'y connaît en informatique
- Allez sur un forum : https://stackoverflow.com/ ou https://www.facebook.com/groups/webdev/
- Engagez un freelance sur Fiverr / Upwork

---

**Félicitations, vous êtes le propriétaire d'un site web professionnel ! 🎉**
