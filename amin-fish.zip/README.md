# 🍤 Snack Amine Poisson — Site Web Officiel

Site officiel du restaurant **Snack Amine** (مطعم أمين للسمك) à Casablanca.

## 🌐 Démo en ligne

Le site est publié à l'adresse (URL de démonstration, à remplacer par votre nom de domaine) :
**`https://snackamine.ma/`**

## 👑 Propriété complète

**Oui, ce site vous appartient à 100 %.** Vous pouvez :
- ✅ Modifier tous les textes, prix, horaires, images
- ✅ Changer les couleurs (1 seule ligne dans `styles.css`)
- ✅ Ajouter/supprimer des plats du menu
- ✅ Changer l'adresse, le téléphone, les réseaux sociaux
- ✅ Héberger le site où vous voulez (Netlify, OVH, Hostinger, etc.)
- ✅ Acheter votre propre nom de domaine (ex: `snackamine.ma`)

## 📂 Structure du site

```
amin-fish/
├── index.html          ← Page principale (HTML)
├── styles.css          ← Tous les styles (couleurs, design)
├── script.js           ← Logique (menu, réservation, langues)
├── site-data.json      ← ⭐ FICHIER PRINCIPAL À MODIFIER ⭐
│                          (nom, menu, prix, horaires, contact)
├── robots.txt          ← Pour Google
├── sitemap.xml         ← Plan du site pour Google
├── admin.html          ← Console simple pour voir les réservations
├── qr-code.png         ← QR code du site (à imprimer)
├── README.md           ← Ce fichier
├── HOW-TO-OWN.md       ← Guide pour prendre le contrôle total
└── images/
    ├── food/           ← Photos des plats
    ├── drinks/         ← Photos des boissons
    └── restaurant/     ← Photos du restaurant
```

## 🛠️ Comment modifier le site

### Modifier le menu, les prix, les horaires
Ouvrez **`site-data.json`** avec un éditeur de texte (Notepad, VS Code, Bloc-notes).
- Changez un prix → sauvegardez → c'est mis à jour sur le site
- Ajoutez un plat → copiez un objet existant et modifiez-le
- Changez les horaires → modifiez la section `hours`

### Modifier les couleurs
Dans `styles.css`, en haut du fichier, changez :
```css
--c-primary: #0a3d4f;     /* Bleu océan (header, titres) */
--c-accent: #e85d4d;      /* Rouge corail (boutons) */
--c-gold: #f0a500;        /* Or (éléments décoratifs) */
--c-sand: #f5e6c8;        /* Sable (fonds) */
```

### Modifier les images
Remplacez simplement les fichiers dans `images/`. Gardez les **mêmes noms** ou changez les `src` dans `index.html`.

### Ajouter une page
Créez un nouveau fichier `.html` (par ex. `events.html`) et ajoutez un lien dans la navigation de `index.html`.

## 📋 Données du site (extrait de `site-data.json`)

| Champ          | Valeur                                        |
|----------------|-----------------------------------------------|
| Nom            | Snack Amine Poisson                           |
| Téléphone      | +212 5225-41331                               |
| WhatsApp       | +212 661-724655                               |
| Email          | contact@snackamine.ma                         |
| Adresse        | 32 Rue Chaouia, Casablanca 20000, Maroc      |
| Langues        | Français / العربية                            |
| Devise         | MAD (Dirham marocain)                         |

## ⏰ Horaires d'ouverture (par défaut)

| Jour       | Horaire           |
|------------|-------------------|
| Lundi      | 10:00 – 23:00     |
| Mardi      | 10:00 – 23:00     |
| Mercredi   | 10:00 – 23:00     |
| Jeudi      | 10:00 – 23:00     |
| Vendredi   | 10:00 – 23:30     |
| Samedi     | 10:00 – 23:30     |
| Dimanche   | 12:00 – 23:00     |

> *Vous pouvez ajuster ces horaires à tout moment dans `site-data.json` → `hours`.*

## 📢 Publier sur Google (SEO)

Le site est déjà optimisé pour Google :
- ✅ Meta tags (titre, description, mots-clés)
- ✅ Open Graph (partage Facebook/WhatsApp)
- ✅ Données structurées Schema.org (Restaurant)
- ✅ Sitemap XML (`sitemap.xml`)
- ✅ `robots.txt` configuré
- ✅ Site 100% responsive (mobile, tablette, desktop)
- ✅ URLs propres avec ancres (#menu, #booking)
- ✅ Images avec attributs `alt`

**Pour indexer le site sur Google :**
1. Allez sur https://search.google.com/search-console/
2. Ajoutez la propriété `https://snackamine.ma/`
3. Vérifiez la propriété (via la balise HTML ou DNS)
4. Soumettez le sitemap : `https://snackamine.ma/sitemap.xml`
5. Demandez l'indexation de la page d'accueil

## 📱 QR Code

Le fichier `qr-code.png` est un QR code qui pointe vers l'URL du site.
- Imprimez-le et placez-le sur les tables
- Les clients peuvent scanner pour voir le menu, réserver, etc.

## 💡 Support

Pour toute question sur la modification du site, consultez `HOW-TO-OWN.md`.

---

**Créé avec ❤️ pour Snack Amine — Bonne dégustation ! 🐟**
