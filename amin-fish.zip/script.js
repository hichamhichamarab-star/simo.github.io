/* ===================================================
   SNACK AMINE POISSON — Site JavaScript
   Loads site-data.json, renders menu/hours, handles
   booking form, language switch, gallery lightbox.
   =================================================== */

(function(){
  'use strict';

  // ============== i18n strings (FR/AR) ==============
  const I18N = {
    fr: {
      brand_sub: 'Poisson & Fruits de mer',
      nav_home: 'Accueil', nav_about: 'À propos', nav_menu: 'Menu', nav_gallery: 'Galerie',
      nav_hours: 'Horaires', nav_book: 'Réserver',
      hero_eyebrow: '★ Casablanca — depuis 20+ ans ★',
      hero_t1: 'Poisson frais &', hero_t2: 'Fruits de mer',
      hero_sub: 'Un restaurant familial au cœur de Casablanca. Saveurs authentiques, produits frais de la mer, ambiance chaleureuse. Réservez votre table en quelques clics.',
      hero_cta1: 'Réserver une table', hero_cta2: 'Voir le menu',
      hero_chip1: 'Ouvert 7j/7', hero_chip2: 'Poisson frais du jour', hero_chip3: 'Centre-ville', hero_chip4: 'À partir de 50 DH',
      about_eyebrow: 'À propos',
      about_title: 'Une tradition familiale de la mer à la table',
      about_p1: 'Depuis plus de deux décennies, <strong>Snack Amine</strong> régale les Casablancais avec les meilleurs poissons frais et fruits de mer. Chaque matin, notre chef sélectionne sur le port les plus belles prises du jour pour vous offrir une cuisine authentique, généreuse et savoureuse.',
      about_p2: 'Que vous veniez en famille, entre amis ou pour un repas d\'affaires, notre équipe vous accueille dans une ambiance conviviale. Nos spécialités ? Le <em>plateau de fruits de mer pour deux</em>, le poisson grillé au charbon et notre fameuse <em>tajine de la mer</em>.',
      about_badge: 'ans d\'expérience',
      about_f1_t: 'Poisson frais quotidien', about_f1_d: 'Sélectionné chaque matin',
      about_f2_t: 'Chefs expérimentés', about_f2_d: 'Cuisine marocaine & méditerranéenne',
      about_f3_t: 'Cadre familial', about_f3_d: 'Idéal groupes & événements',
      about_f4_t: 'Prix abordables', about_f4_d: 'Excellent rapport qualité-prix',
      menu_eyebrow: 'Notre carte',
      menu_title: 'Le meilleur de la mer, dans votre assiette',
      menu_sub: 'Une carte variée mettant à l\'honneur les produits frais et les recettes traditionnelles marocaines. Tous nos plats sont préparés à la commande.',
      menu_note: '* Prix indicatifs en dirhams (DH). Le prix du poisson au kilogramme varie selon la pêche du jour.',
      gal_eyebrow: 'Galerie', gal_title: 'Plats, ambiance & sourires',
      hours_eyebrow: 'Temps de travail', hours_title: 'Ouvert toute la semaine',
      hours_p: 'Nous vous accueillons <strong>7 jours sur 7</strong> pour vous régaler de nos meilleurs poissons et fruits de mer. Service midi et soir, tous les jours.',
      hours_call: 'Appelez-nous',
      hours_table_t: 'Horaire d\'ouverture',
      book_eyebrow: 'Réservation', book_title: 'Réservez votre table',
      book_sub: 'Réservez en quelques secondes. Confirmation par téléphone ou WhatsApp.',
      bk_name: 'Nom complet *', bk_phone: 'Téléphone *',
      bk_date: 'Date *', bk_time: 'Heure *', bk_guests: 'Nombre de personnes *',
      bk_msg: 'Message (optionnel)',
      bk_submit: 'Confirmer la réservation',
      bk_whatsapp: 'Ou via WhatsApp',
      bk_legal: 'En soumettant ce formulaire, vous acceptez d\'être recontacté. Vos données ne sont jamais partagées.',
      bk_ok_t: 'Réservation enregistrée !',
      bk_ok_p: 'Merci <span id="bk-ok-name"></span> ! Votre demande pour <strong id="bk-ok-guests"></strong> pers. le <strong id="bk-ok-date"></strong> à <strong id="bk-ok-time"></strong> a bien été reçue.',
      bk_ok_p2: 'Notre équipe vous contactera au <strong id="bk-ok-phone"></strong> pour confirmer.',
      bk_ok_new: 'Faire une autre réservation',
      loc_eyebrow: 'Nous trouver', loc_title: 'Au cœur de Casablanca',
      loc_directions: 'Itinéraire Google Maps',
      footer_about: 'Restaurant familial au cœur de Casablanca. Poisson frais, fruits de mer, cuisine marocaine & méditerranéenne.',
      footer_contact_t: 'Contact', footer_links_t: 'Liens rapides', footer_follow_t: 'Suivez-nous',
      footer_qr: 'Télécharger le QR code',
      footer_rights: 'Tous droits réservés.',
      footer_data: 'Données du site',
      closed: 'Fermé'
    },
    ar: {
      brand_sub: 'سمك ومأكولات بحرية',
      nav_home: 'الرئيسية', nav_about: 'من نحن', nav_menu: 'القائمة', nav_gallery: 'معرض الصور',
      nav_hours: 'ساعات العمل', nav_book: 'احجز',
      hero_eyebrow: '★ الدار البيضاء — أكثر من 20 سنة ★',
      hero_t1: 'سمك طازج و', hero_t2: 'مأكولات بحرية',
      hero_sub: 'مطعم عائلي في قلب الدار البيضاء. نكهات أصيلة، منتجات بحرية طازجة، أجواء دافئة. احجز طاولتك في ثوانٍ.',
      hero_cta1: 'احجز طاولة', hero_cta2: 'شاهد القائمة',
      hero_chip1: 'مفتوح 7/7', hero_chip2: 'سمك طازج كل يوم', hero_chip3: 'وسط المدينة', hero_chip4: 'ابتداءً من 50 درهم',
      about_eyebrow: 'من نحن',
      about_title: 'تقاليد عائلية من البحر إلى المائدة',
      about_p1: 'منذ أكثر من عقدين، يفاجئ <strong>سناك أمين</strong> سكان الدار البيضاء بأجود أنواع السمك الطازج والمأكولات البحرية. كل صباح، يختار طاهينا أجمل الأسماك من الميناء ليقدم لك مأكولات أصيلة ولذيذة.',
      about_p2: 'سواءً كنت قادماً مع العائلة أو الأصدقاء أو في مناسبة عمل، فريقنا يستقبلك في جو ودود. تخصصاتنا؟ <em>طبق المأكولات البحرية لشخصين</em>، السمك المشوي على الفحم، و<em>طاجين البحر</em> الشهير.',
      about_badge: 'سنة من الخبرة',
      about_f1_t: 'سمك طازج يومياً', about_f1_d: 'مختار كل صباح',
      about_f2_t: 'طهاة ذوو خبرة', about_f2_d: 'مطبخ مغربي ومتوسطي',
      about_f3_t: 'إطار عائلي', about_f3_d: 'مثالي للمجموعات والمناسبات',
      about_f4_t: 'أسعار معقولة', about_f4_d: 'أفضل قيمة مقابل الثمن',
      menu_eyebrow: 'قائمتنا',
      menu_title: 'أجود ما في البحر في طبقك',
      menu_sub: 'قائمة متنوعة تبرز المنتجات الطازجة والوصفات المغربية الأصيلة. كل الأطباق تُحضر عند الطلب.',
      menu_note: '* أسعار استرشادية بالدرهم. سعر السمك بالكيلوغرام يتغير حسب الصيد اليومي.',
      gal_eyebrow: 'معرض الصور', gal_title: 'أطباق، أجواء وابتسامات',
      hours_eyebrow: 'وقت العمل', hours_title: 'مفتوح طوال الأسبوع',
      hours_p: 'نرحب بكم <strong>7 أيام في الأسبوع</strong> للاستمتاع بأجود الأسماك والمأكولات البحرية. خدمة الغداء والعشاء يومياً.',
      hours_call: 'اتصل بنا',
      hours_table_t: 'ساعات العمل',
      book_eyebrow: 'الحجز', book_title: 'احجز طاولتك',
      book_sub: 'احجز في ثوانٍ. تأكيد عبر الهاتف أو واتساب.',
      bk_name: 'الاسم الكامل *', bk_phone: 'الهاتف *',
      bk_date: 'التاريخ *', bk_time: 'الوقت *', bk_guests: 'عدد الأشخاص *',
      bk_msg: 'رسالة (اختياري)',
      bk_submit: 'تأكيد الحجز',
      bk_whatsapp: 'أو عبر واتساب',
      bk_legal: 'بإرسال هذا النموذج، توافق على أن نتصل بك لتأكيد الحجز. لن نشارك بياناتك أبداً.',
      bk_ok_t: 'تم تسجيل الحجز!',
      bk_ok_p: 'شكراً <span id="bk-ok-name"></span>! تم استلام طلب حجزك لـ <strong id="bk-ok-guests"></strong> أشخاص في <strong id="bk-ok-date"></strong> على الساعة <strong id="bk-ok-time"></strong>.',
      bk_ok_p2: 'سيتواصل معك فريقنا على الرقم <strong id="bk-ok-phone"></strong> للتأكيد.',
      bk_ok_new: 'حجز جديد',
      loc_eyebrow: 'موقعنا', loc_title: 'في قلب الدار البيضاء',
      loc_directions: 'الاتجاهات عبر Google Maps',
      footer_about: 'مطعم عائلي في قلب الدار البيضاء. سمك طازج، مأكولات بحرية، مطبخ مغربي ومتوسطي.',
      footer_contact_t: 'اتصل بنا', footer_links_t: 'روابط سريعة', footer_follow_t: 'تابعنا',
      footer_qr: 'تحميل رمز QR',
      footer_rights: 'جميع الحقوق محفوظة.',
      footer_data: 'بيانات الموقع',
      closed: 'مغلق'
    }
  };

  // ============== Helpers ==============
  const $  = (s, p=document) => p.querySelector(s);
  const $$ = (s, p=document) => Array.from(p.querySelectorAll(s));

  // Detect / persist language
  const getLang = () => localStorage.getItem('amin_lang') || 'fr';
  const setLang = (l) => localStorage.setItem('amin_lang', l);

  // Apply language to all [data-i18n] elements
  function applyLang(lang){
    const dict = I18N[lang] || I18N.fr;
    $$('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key] !== undefined) el.innerHTML = dict[key];
    });
    document.documentElement.lang = lang;
    document.body.dir = (lang === 'ar') ? 'rtl' : 'ltr';
    $$('.lang-btn').forEach(b => b.classList.toggle('active', b.dataset.lang === lang));
  }

  // ============== Load site data (editable JSON) ==============
  let SITE = null;
  async function loadSiteData(){
    try {
      const res = await fetch('site-data.json', { cache: 'no-store' });
      SITE = await res.json();
    } catch (e) {
      console.error('Failed to load site-data.json', e);
      SITE = { name: 'Snack Amine', menu: [], hours: [] };
    }
    renderMenu();
    renderHours();
  }

  // ============== Menu ==============
  let currentCat = 0;
  function renderMenu(){
    const tabs = $('#menuTabs');
    const grid = $('#menuGrid');
    if (!tabs || !grid || !SITE.menu) return;

    tabs.innerHTML = SITE.menu.map((c, i) =>
      `<button class="menu__tab${i===0?' active':''}" data-i="${i}">${escapeHTML(c.category)}</button>`
    ).join('');

    grid.innerHTML = SITE.menu.flatMap(c => c.items.map(it => `
      <article class="menu__card" data-cat="${SITE.menu.indexOf(c)}">
        <div class="menu__card-head">
          <div>
            <h3 class="menu__card-name">${escapeHTML(it.name)}</h3>
            <span class="menu__card-name-ar">${escapeHTML(it.nameAr || '')}</span>
          </div>
          <span class="menu__card-price">${it.price} DH</span>
        </div>
        <p class="menu__card-desc">${escapeHTML(it.desc || '')}</p>
      </article>
    `)).join('');

    $$('.menu__tab', tabs).forEach(btn => {
      btn.addEventListener('click', () => {
        $$('.menu__tab', tabs).forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const i = parseInt(btn.dataset.i, 10);
        $$('.menu__card', grid).forEach(card => {
          card.classList.toggle('hidden', parseInt(card.dataset.cat, 10) !== i);
        });
      });
    });

    // Hide cards not in first category initially
    $$('.menu__card', grid).forEach((card, idx) => {
      // All visible - let user see variety on first load
      // If you want tabbed: uncomment below
      // const cat = parseInt(card.dataset.cat, 10);
      // card.classList.toggle('hidden', cat !== 0);
    });
  }

  // ============== Hours ==============
  function renderHours(){
    const list = $('#hoursList');
    if (!list || !SITE.hours) return;
    const todayIdx = (new Date().getDay() + 6) % 7; // Monday=0
    list.innerHTML = SITE.hours.map((h, i) => {
      const closed = h.closed;
      const time = closed
        ? I18N[getLang()].closed
        : `${h.open} – ${h.close}`;
      return `<li class="${i===todayIdx?'is-today':''} ${closed?'closed':''}">
        <span class="day">${escapeHTML(h.day)}</span>
        <span class="time">${time}</span>
      </li>`;
    }).join('');
  }

  // ============== Booking form ==============
  function setupBooking(){
    const form  = $('#bookingForm');
    const succ  = $('#bookingSuccess');
    const newBtn = $('#bkNew');
    if (!form) return;

    // Min date = today
    const dateEl = $('#bk-date');
    if (dateEl) {
      const t = new Date();
      const yyyy = t.getFullYear();
      const mm = String(t.getMonth()+1).padStart(2,'0');
      const dd = String(t.getDate()).padStart(2,'0');
      dateEl.min = `${yyyy}-${mm}-${dd}`;
    }

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const data = {
        id: 'BK-' + Date.now().toString(36).toUpperCase(),
        name:    form.name.value.trim(),
        phone:   form.phone.value.trim(),
        date:    form.date.value,
        time:    form.time.value,
        guests:  form.guests.value,
        message: form.message.value.trim(),
        createdAt: new Date().toISOString(),
        lang: getLang()
      };

      // Validate
      let ok = true;
      $$('input[required], select[required]', form).forEach(el => {
        if (!el.value || (el.pattern && !new RegExp(el.pattern).test(el.value))) {
          el.classList.add('error');
          setTimeout(() => el.classList.remove('error'), 600);
          ok = false;
        }
      });
      if (!ok) return;

      // Save locally
      const list = JSON.parse(localStorage.getItem('amin_bookings') || '[]');
      list.push(data);
      localStorage.setItem('amin_bookings', JSON.stringify(list));

      // Show success
      $('#bk-ok-name').textContent   = data.name;
      $('#bk-ok-guests').textContent = data.guests;
      $('#bk-ok-date').textContent   = formatDateFR(data.date);
      $('#bk-ok-time').textContent   = data.time;
      $('#bk-ok-phone').textContent  = data.phone;

      form.hidden = true;
      succ.hidden = false;
      succ.scrollIntoView({ behavior: 'smooth', block: 'center' });

      // Also open WhatsApp in a new tab (optional fallback)
      const msg = encodeURIComponent(
        `Bonjour Snack Amine,\nJe souhaite réserver une table.\n\n` +
        `Nom: ${data.name}\nTéléphone: ${data.phone}\n` +
        `Date: ${data.date}\nHeure: ${data.time}\nPersonnes: ${data.guests}\n` +
        (data.message ? `Message: ${data.message}\n` : '')
      );
      // Don't auto-open - just suggest. User can click the WhatsApp button.
      // window.open(`https://wa.me/212661724655?text=${msg}`, '_blank');
    });

    newBtn && newBtn.addEventListener('click', () => {
      form.reset();
      form.hidden = false;
      succ.hidden = true;
      form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  // ============== Navigation: mobile toggle + scroll spy ==============
  function setupNav(){
    const nav = $('#nav');
    const toggle = $('#navToggle');
    const menu = $('#navMenu');

    toggle && toggle.addEventListener('click', () => {
      toggle.classList.toggle('open');
      menu.classList.toggle('open');
    });

    $$('a', menu).forEach(a => {
      a.addEventListener('click', () => {
        toggle.classList.remove('open');
        menu.classList.remove('open');
      });
    });

    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 30);
    }, { passive: true });
  }

  // ============== Gallery lightbox ==============
  function setupLightbox(){
    const lb = $('#lightbox');
    const lbImg = $('#lbImg');
    const lbClose = $('#lbClose');
    if (!lb) return;

    $$('[data-lightbox]').forEach(a => {
      a.addEventListener('click', (e) => {
        e.preventDefault();
        lbImg.src = a.href;
        lbImg.alt = a.querySelector('img')?.alt || '';
        lb.hidden = false;
        document.body.style.overflow = 'hidden';
      });
    });

    const close = () => {
      lb.hidden = true;
      document.body.style.overflow = '';
    };
    lbClose.addEventListener('click', close);
    lb.addEventListener('click', (e) => { if (e.target === lb) close(); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !lb.hidden) close(); });
  }

  // ============== Language switcher ==============
  function setupLang(){
    $$('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const l = btn.dataset.lang;
        setLang(l);
        applyLang(l);
        renderHours(); // re-render to translate "Fermé"
      });
    });
  }

  // ============== Reveal on scroll ==============
  function setupReveal(){
    const els = $$('.section, .hero__content, .menu__card, .gallery__item, .hours__contact-item, .about__feature, .location__info, .location__map');
    els.forEach(el => el.classList.add('reveal'));
    if (!('IntersectionObserver' in window)) {
      els.forEach(el => el.classList.add('in'));
      return;
    }
    const io = new IntersectionObserver((entries) => {
      entries.forEach(en => {
        if (en.isIntersecting) {
          en.target.classList.add('in');
          io.unobserve(en.target);
        }
      });
    }, { threshold: 0.08 });
    els.forEach(el => io.observe(el));
  }

  // ============== Util ==============
  function escapeHTML(s){
    return (s || '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]);
  }
  function formatDateFR(iso){
    if (!iso) return '';
    const [y, m, d] = iso.split('-');
    return `${d}/${m}/${y}`;
  }

  // ============== Init ==============
  document.addEventListener('DOMContentLoaded', () => {
    $('#year') && ($('#year').textContent = new Date().getFullYear());
    applyLang(getLang());
    setupLang();
    setupNav();
    setupLightbox();
    setupBooking();
    setupReveal();
    loadSiteData();
  });

})();
